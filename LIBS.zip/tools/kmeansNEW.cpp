//KMEANS
//https://github.com/marcoscastro/kmeans/blob/master/kmeans.cpp
class PointM
{
private:
	int id_point, id_cluster;
	vector<double> values;
	int total_values;
	string name;

public:
	PointM(int id_point, vector<double>& values, string name = "")
	{
		this->id_point = id_point;
		total_values = values.size();

		for(int i = 0; i < total_values; i++)
			this->values.push_back(values[i]);

		this->name = name;
		id_cluster = -1;
	}

	int getID()
	{
		return id_point;
	}

	void setCluster(int id_cluster)
	{
		this->id_cluster = id_cluster;
	}

	int getCluster()
	{
		return id_cluster;
	}

	double getValue(int index)
	{
		return values[index];
	}

	int getTotalValues()
	{
		return total_values;
	}

	void addValue(double value)
	{
		values.push_back(value);
	}

	string getName()
	{
		return name;
	}
};

class Cluster
{
private:
	int id_cluster;
	vector<double> central_values;
	vector<PointM> points;

public:
	Cluster(int id_cluster, PointM point)
	{
		this->id_cluster = id_cluster;

		int total_values = point.getTotalValues();

		for(int i = 0; i < total_values; i++)
			central_values.push_back(point.getValue(i));

		points.push_back(point);
	}

	void addPoint(PointM point)
	{
		points.push_back(point);
	}

	bool removePoint(int id_point)
	{
		int total_points = points.size();

		for(int i = 0; i < total_points; i++)
		{
			if(points[i].getID() == id_point)
			{
				points.erase(points.begin() + i);
				return true;
			}
		}
		return false;
	}

	double getCentralValue(int index)
	{
		return central_values[index];
	}

	void setCentralValue(int index, double value)
	{
		central_values[index] = value;
	}

	PointM getPoint(int index)
	{
		return points[index];
	}

	int getTotalPoints()
	{
		return points.size();
	}

	int getID()
	{
		return id_cluster;
	}
};

class KMeans
{
private:
	int K; // number of clusters
	int total_values, total_points, max_iterations;
	vector<Cluster> clusters;

	// return ID of nearest center (uses euclidean distance)
	int getIDNearestCenter(PointM point)
	{
		double sum = 0.0, min_dist;
		int id_cluster_center = 0;

		for(int i = 0; i < total_values; i++)
		{
			sum += pow(clusters[0].getCentralValue(i) -
					   point.getValue(i), 2.0);
		}

		min_dist = sqrt(sum);

		for(int i = 1; i < K; i++)
		{
			double dist;
			sum = 0.0;

			for(int j = 0; j < total_values; j++)
			{
				sum += pow(clusters[i].getCentralValue(j) -
						   point.getValue(j), 2.0);
			}

			dist = sqrt(sum);

			if(dist < min_dist)
			{
				min_dist = dist;
				id_cluster_center = i;
			}
		}

		return id_cluster_center;
	}

public:
	KMeans(int K, int total_points, int total_values, int max_iterations)
	{
		this->K = K;
		this->total_points = total_points;
		this->total_values = total_values;
		this->max_iterations = max_iterations;
	}

	vector<double> run(vector<PointM> & points, int maxPointCount, Mat flow, Mat cflow)//int run(vector<PointM> & points)//void run(vector<PointM> & points)
	{
		if(K > total_points){
			vector<double> returnValue;
			return returnValue;//return 0;
		}

		vector<int> prohibited_indexes;

		// choose K distinct values for the centers of the clusters
		for(int i = 0; i < K; i++)
		{
			while(true)
			{
				int index_point = rand() % total_points;

				if(find(prohibited_indexes.begin(), prohibited_indexes.end(),
						index_point) == prohibited_indexes.end())
				{
					prohibited_indexes.push_back(index_point);
					points[index_point].setCluster(i);
					Cluster cluster(i, points[index_point]);
					clusters.push_back(cluster);
					break;
				}
			}
		}

		int iter = 1;

		while(true)
		{
			bool done = true;

			// associates each point to the nearest center
			for(int i = 0; i < total_points; i++)
			{
				int id_old_cluster = points[i].getCluster();
				int id_nearest_center = getIDNearestCenter(points[i]);

				if(id_old_cluster != id_nearest_center)
				{
					if(id_old_cluster != -1)
						clusters[id_old_cluster].removePoint(points[i].getID());

					points[i].setCluster(id_nearest_center);
					clusters[id_nearest_center].addPoint(points[i]);
					done = false;
				}
			}

			// recalculating the center of each cluster
			for(int i = 0; i < K; i++)
			{
				for(int j = 0; j < total_values; j++)
				{
					int total_points_cluster = clusters[i].getTotalPoints();
					double sum = 0.0;

					if(total_points_cluster > 0)
					{
						for(int p = 0; p < total_points_cluster; p++)
							sum += clusters[i].getPoint(p).getValue(j);
						clusters[i].setCentralValue(j, sum / total_points_cluster);
					}
				}
			}

			if(done == true || iter >= max_iterations)
			{
				//cout << "Break in iteration " << iter << "\n\n";
				break;
			}

			iter++;
		}

		// shows elements of clusters
		if(1==0){
			for(int i = 0; i < K; i++)
			{
				int total_points_cluster =  clusters[i].getTotalPoints();

				cout << "Cluster " << clusters[i].getID() + 1 << endl;
				for(int j = 0; j < total_points_cluster; j++)
				{
					cout << "Point " << clusters[i].getPoint(j).getID() + 1 << ": ";
					for(int p = 0; p < total_values; p++)
						cout << clusters[i].getPoint(j).getValue(p) << " ";

					string point_name = clusters[i].getPoint(j).getName();

					if(point_name != "")
						cout << "- " << point_name;

					cout << endl;
				}

				cout << "Cluster values: ";

				for(int j = 0; j < total_values; j++)
					cout << clusters[i].getCentralValue(j) << " ";

				cout << "\n\n";
			}
		}


		//ASSUME 2 clusters for flow field
		if(1==0){
			int returnValue = 0;
		
			int total_points_clusterA = clusters[0].getTotalPoints();
			int total_points_clusterB = clusters[1].getTotalPoints();

			int smallestCluster = 0;
			if(total_points_clusterB < total_points_clusterA){
				smallestCluster = 1;		
			}
			int total_points_smallest_cluster = clusters[smallestCluster].getTotalPoints();

			if(total_points_smallest_cluster < 30)//define this dynamically based on step chosen to grab vectors from field
			{
				returnValue = clusters[smallestCluster].getPoint(0).getID(); //get one of the points, not need more if cluster members really close
			}
			//return returnValue;
		}

		if(K==2 || 1==1){
			vector<double> returnValue;

			int total_points_clusterA = clusters[0].getTotalPoints();
			int total_points_clusterB = clusters[1].getTotalPoints();

			int smallestCluster = 0;
			if(total_points_clusterB < total_points_clusterA){
				smallestCluster = 1;		
			}
			int total_points_smallest_cluster = clusters[smallestCluster].getTotalPoints();

			//check biggest cluster for uniformity, assume static background (backStatic = true) if below threshold
			int largestCluster = 0;
			if(smallestCluster==0){largestCluster = 1;}
			int total_points_largest_cluster = clusters[largestCluster].getTotalPoints();
			double sumX = 0;
			double sumY = 0;
			double sumDX,sumDY = 0;
			double summeanMedianDY = 0;
			double count_pointsA = 0;

			if(1==0){
				//for(int i = 0; i < clusters[largestCluster].getTotalPoints(); i += 1){ //for(int i = 0; i < pointOfInterest.size(); i += 1){ 
					for(int y = 0; y < cflow.rows; y += 1){
						for(int x = 0; x < cflow.cols; x += 1)
						{
							//if(count_pointsA > 0 && count_pointsA == clusters[largestCluster].getPoint(i).getID()){
								const Point2f& fxy = flow.at<Point2f>(y, x);

								//sumX = sumX + abs(fxy.x);
								sumY = sumY + abs(fxy.y);
								sumX = sumX + sqrt(fxy.x * fxy.x + fxy.y * fxy.y);			
								sumDX = sumDX + fxy.x;
								sumDY = sumDY + fxy.y;

								//clusterCenterX = clusterCenterX + x + fxy.x;
								//clusterCenterY = clusterCenterY + y + fxy.y;
								//vX.push_back(x + fxy.x);
								//vY.push_back(y + fxy.y);		
								//circle(cflow, Point(cvRound(x+fxy.x), cvRound(y+fxy.y)), 5,  CV_RGB(255, 0, 0), -1);
							//}
							count_pointsA++;
						}			
					}
				//}
				//sumX = 100000 * sumX / (cflow.rows * cflow.cols);
				sumX = 1000 * sumX /  (cflow.rows * cflow.cols);//clusters[largestCluster].getTotalPoints();
				sumY = 100000 * sumY / (cflow.rows * cflow.cols);

				sumDX = sumDX  * 0.100105;
				sumDY = sumDY  * 0.100105;
				circle(cflow, Point(cvRound((cflow.cols/2)+0), cvRound((cflow.rows/2)+0)), 5,  CV_RGB(255, 0, 0), -1);
				line(cflow, Point(cvRound((cflow.cols/2)+0), cvRound((cflow.rows/2)+0)), 
				Point(cvRound((cflow.cols/2)+sumDX), cvRound((cflow.rows/2)+sumDY)), CV_RGB(255, 255, 0));
				circle(cflow, Point(cvRound((cflow.cols/2)+sumDX), cvRound((cflow.rows/2)+sumDY)), 5,  CV_RGB(255, 0, 0), -1);

				emulatedCameraDirectionX = sumDX;
				emulatedCameraDirectionY = sumDY;

				//cout << "sumX=" << sumX << endl;
				//cout << "sumX=" << sumX << " ,sumY = " << sumY << endl;
				//if(sumX < 0.05 && sumY < 0.05 && sumX >  0.0001 && sumY > 0.0001){
				if(sumX < 99){
					backStatic = true;
					//cout << "BACK STATIC, sumX=" << sumX << ", sumY=" << sumY << endl;			
				}else{
					backStatic = false;
	    			}
			}

			/////
			bool sparseMode = true;
			if(sparseMode){
				if(total_points_largest_cluster - total_points_smallest_cluster < 15){
					smallestCluster = largestCluster;
					maxPointCount = 100; //////////////////// OVERRIDE WHEN MODE IS SPARSE
				}
				maxPointCount = 100;//maxPointCount = 30;
				smallestCluster = largestCluster;
			}			


			if(total_points_smallest_cluster < maxPointCount)//define this dynamically based on step chosen to grab vectors from field
			{
				//returnValue = clusters[smallestCluster].getPoint(0).getID(); //just get one of the points, not need more if cluster members really close
				int total_points_cluster =  clusters[smallestCluster].getTotalPoints();

				//cout << "Cluster " << clusters[smallestCluster].getID() + 1 << endl;
				for(int j = 0; j < total_points_cluster; j++)
				{
					//cout << "Point " << clusters[smallestCluster].getPoint(j).getID() + 1 << ": " << endl;
					returnValue.push_back(clusters[smallestCluster].getPoint(j).getID());

					//for(int p = 0; p < total_values; p++){
						//cout << clusters[smallestCluster].getPoint(j).getValue(p) << " ";
					//}

					//string point_name = clusters[smallestCluster].getPoint(j).getName();

					//if(point_name != ""){
					//	cout << "- " << point_name;
					//}

					//cout << endl;
				}

				//cout << "Cluster values: ";

				//for(int j = 0; j < total_values; j++){
				//	cout << clusters[smallestCluster].getCentralValue(j) << " ";	
				//	returnValue.push_back(clusters[smallestCluster].getCentralValue(j));				
				//}				

				//cout << "\n\n";
			}

			return returnValue;
		}

		
	}


  ///vector<vector<Point>> trajectory_Poins; //trajectory_Poins_scale

	//exract mean and median of cluster
	void meanMedian(vector<PointM> & points, vector<PointM> & pointsXY, vector<double> pointOfInterest, Mat flow, Mat cflow, int step, double flowImageScale){
		
		//Convert point IDs to points and take average and mean
		int ceiling = pointOfInterest.size();// - 2;
		if(ceiling < 0){
			ceiling=0;
		}
		double clusterCenterX = 0;
		double clusterCenterY = 0;
		vector<double> vX;
		vector<double> vY;

if(1==0){ //A -- if full flow map is used
		for(int i = 0; i < ceiling; i += 1){ //parse all returned values, besides last two that are not IDs, but the X,Y of centroid of cluster
			double count_pointsA = 0;
			for(int y = 0; y < cflow.rows; y += step){
				for(int x = 0; x < cflow.cols; x += step)
				{
					if(count_pointsA > 0 && count_pointsA == pointOfInterest[i]){
						const Point2f& fxy = flow.at<Point2f>(y, x);
						clusterCenterX = clusterCenterX + x + fxy.x;
						clusterCenterY = clusterCenterY + y + fxy.y;
						vX.push_back(x + fxy.x);
						vY.push_back(y + fxy.y);
						//cout<<"point Of Interest X,Y = " << Point(cvRound(x+fxy.x), cvRound(y+fxy.y)) << endl;
						//circle(cflow, Point(cvRound(x+fxy.x), cvRound(y+fxy.y)), 5,  CV_RGB(255, 0, 0), -1);
						//if(previewAssisted){
						//	circle(plotFrame, Point(cvRound(x+fxy.x) / flowImageScale, 
						//	cvRound(y+fxy.y) / flowImageScale), 5,  CV_RGB(255, 0, 0), -1);				
							//DRAW FLOW VECTORS for identified								
						//	line(plotFrame, Point((x/ flowImageScale),(y/ flowImageScale)), 
						//	Point((cvRound(x+fxy.x*2)/ flowImageScale), 
						//	(cvRound(y+fxy.y*2) / flowImageScale)), CV_RGB(255, 111, 0));
						//}
					}
					count_pointsA++;
				}			
			}
		}
}//END if 1==0 A

		//USE for sparse seection of values to k means input from full flow map
bool sparseMode = true;
if(sparseMode){
		for(int i = 0; i < pointOfInterest.size(); i += 1){ 			
			//const Point2f& fxy = flow.at<Point2f>(y, x);
			float xValue =  pointsXY[pointOfInterest[i]].getValue(0) + 0;//points[pointOfInterest[i]].getValue(0);
			float yValue =  pointsXY[pointOfInterest[i]].getValue(1) + 0;//points[pointOfInterest[i]].getValue(1);
			clusterCenterX = clusterCenterX + xValue;
			clusterCenterY = clusterCenterY + yValue;
			vX.push_back(xValue);
			vY.push_back(yValue);

			circle(cflow, Point(xValue,yValue), 4,  CV_RGB(155, 211, 255), -1);
		}
}

		//draw cluster center
		clusterCenterX = clusterCenterX / ceiling;	
		clusterCenterY = clusterCenterY / ceiling;
	
		//if(pointOfInterest.size() > 0){
			//cout<<"points Of Interest Centroid = " << Point((clusterCenterX), (clusterCenterY)) << endl;
			//if(previewFlows){
			//	circle(cflow, Point((clusterCenterX), (clusterCenterY)), 12,  CV_RGB(255, 0, 255), -1);
			//}
			//if(previewAssisted){
			//	circle(plotFrame, Point((clusterCenterX) / flowImageScale, 
			//	(clusterCenterY) / flowImageScale), 12,  CV_RGB(255, 0, 255), -1);
			//}
		//}

		//take MEDIAN
		if(pointOfInterest.size() > 1){
			
			//CALCULATE MEDIAN
			double medianX = 0;
			double medianY = 0;
			sort(vX.begin(), vX.end());
			if (vX.size() % 2 == 0){
				medianX = (vX[vX.size()/2 - 1] + vX[vX.size()/2]) / 2 ;
			}
			else{
				medianX = vX[vX.size()/2];
			}
			sort(vY.begin(), vY.end());
			if (vY.size() % 2 == 0){
				medianY = (vY[vY.size()/2 - 1] + vY[vY.size()/2]) / 2 ;
			}
			else{
				medianY = vY[vY.size()/2];
			}
			///END CALCULATE MEDIAN	

			//CALCULATE BOUNDING BOX - take only points close to median center, use sorted matrix from MEDIAN calculation
			double estimateWidth = vX.size() * 40; //40 pixels from flow sample to the next
			double estimateHeight = vY.size() * 40;
			//END CALCULATE  BOUNDING BOX		

			//RESET IF CENTER MEDIAN between a distance to current rectangle
			double clusterCenterXScaled = medianX / flowImageScale; //MEDIAN CENTER SCALED
			double clusterCenterYScaled = medianY / flowImageScale;
			double clusterMeanXScaled = clusterCenterX / flowImageScale;
			double clusterMeanYScaled = clusterCenterY / flowImageScale;

			//cout<<"points Of Interest Centroid = " << Point((medianX), (medianY)) << endl;
			//if(previewFlows){

						
				
				circle(cflow, Point((medianX), (medianY)), 5,  CV_RGB(155, 111, 255), -1);
				//circle(cflow, Point((clusterCenterX), (clusterCenterY)), 5,  CV_RGB(255, 111, 255), -1);
				//medianX = clusterCenterX;
				//medianY = clusterCenterY;


				//////////////////////// TRAJECTORIES PLOT /////////// 
				//assign current found center to closest point in trajctories structure, if above a threshold define new trajectory
				int closestTrajectoryID = 0;
				//create first
				if( trajectory_Poins.size() == 0){
					vector<Point> startVec;
					trajectory_Poins.push_back(startVec);
					//trajectory_Poins_scale
				}
				

				bool showOnlyLast = true;
				if(showOnlyLast){
					//trajectory_Poins.clear();
					//vector<Point> startVecN;
					//trajectory_Poins.push_back(startVecN);
					trajectory_Poins[0].push_back(Point((medianX), (medianY)));
					trajectory_Poins_scale.push_back(estimateWidth);
				}else{
					int countLast = trajectory_Poins[0].size();
					if(countLast > 0){				
						//check against last point of 1st in sruct
						float currentLenINIT = sqrt( (medianX - trajectory_Poins[0][countLast-1].x) * (medianX - trajectory_Poins[0][countLast-1].x) + 
							(medianY - trajectory_Poins[0][countLast-1].y)*(medianY - trajectory_Poins[0][countLast-1].y));								
						float minDist = currentLenINIT;
						for(int i = 0; i < trajectory_Poins.size(); i += 1){ 
							//check new against kept
							//for(int j = 0; j< trajectory_Poins[i].size(); j += 1){ //ONLY CHECK LAST POINT 
								int j =  trajectory_Poins[i].size()-1;
								float currentLen = sqrt( (medianX - trajectory_Poins[i][j].x) * (medianX - trajectory_Poins[i][j].x) + //check against last point of 1st in sruct
								(medianY - trajectory_Poins[i][j].y)*(medianY - trajectory_Poins[i][j].y) ) ;
								if(currentLen < minDist){
									minDist = currentLen;
									closestTrajectoryID = i;
								}
							//}
						}
						if(minDist > 35){ //if too large, start new trajectory
							vector<Point> startVec;
							trajectory_Poins.push_back(startVec);
							trajectory_Poins[trajectory_Poins.size()-1].push_back(Point((medianX), (medianY)));
						}else{
							trajectory_Poins[closestTrajectoryID].push_back(Point((medianX), (medianY)));
						}
						cout << "TRAJECTORY POINTS COUNT = " << trajectory_Poins[closestTrajectoryID].size() << endl;
					}else{
						trajectory_Poins[closestTrajectoryID].push_back(Point((medianX), (medianY)));
					}
				}
				
			//}
			//if(previewAssisted){
			//	circle(plotFrame, Point(clusterCenterXScaled, clusterCenterYScaled), 15,  CV_RGB(255, 255, 255), -1);
			//}
			
			//double CentersDistance = DistanceXYtoBBoxCenter(bbox, clusterCenterXScaled, clusterCenterYScaled);
			//double CentersMedianDistance = DistancePointToPoint(clusterMeanXScaled,clusterMeanYScaled, clusterCenterXScaled, clusterCenterYScaled);

			//cout<<"Center differences = " <<centerXdiff << ", " << centerYdiff << ", distance = "<< CentersDistance << endl;
			
			//END RESET IF CENTER MEDIAN between a distance to current rectangle
		}
		if(1==0){
			for(int i = 0; i < trajectory_Poins.size(); i += 1){ 
				if( trajectory_Poins[i].size() > 10){
					for(int j = 0; j< trajectory_Poins[i].size(); j += 1){ 
						//line(cflow, Point(cvRound((cflow.cols/2)+0), cvRound((cflow.rows/2)+0)), Point(cvRound((cflow.cols/2)+sumDX), cvRound((cflow.rows/2)+sumDY)), CV_RGB(255, 255, 0));
						if(j > 0){
							line(cflow, trajectory_Poins[i][j],trajectory_Poins[i][j-1], CV_RGB(255, 255, 0));
						}
					}
				}
			}
		}
			
	}


};
//END KMEANS
