
//#include "tracking.hpp"

#include <opencv2/tracking.hpp>
#include <opencv2/core/ocl.hpp>
#include <opencv2/opencv.hpp>
#include "kcftracker.hpp"
 
//using namespace cv;
using namespace std;
using namespace cv;
 
 
int main(int argc, char* argv[])
{
    // Create a tracker
    KCFTracker tracker(true, true, true, true);

    VideoCapture video;

    if(argv[1]){
        cout << argv[1] << endl;
        std::string videopath =  argv[1];
        video.open(videopath);
    }
    else{
        // Read video
        video.open("../../videos/drones.mp4");
    }

    video.set(3, 500);
    video.set(4, 480);
     
    // Exit if video is not opened
    if(!video.isOpened())
    {
        cout << "Could not read video file" << endl; 
        return 1; 
    } 
 
    // Read first frame 
    Mat frame; 
    bool ok = video.read(frame); 
 
    // Define initial bounding box 
    Rect2d bbox; 
    //cout << bbox << endl;
    
    // Uncomment the line below to select a different bounding box 
    
    // Display bounding box. 
    //rectangle(frame, bbox, Scalar( 255, 0, 0 ), 2, 1 ); 
 
    //imshow("Tracking", frame); 
    namedWindow("Tracking");
    moveWindow("Tracking", 20,20);
     
    while(video.read(frame))
    {     
        // Start timer
        resize(frame, frame, Size(1280, 860));

        

        if(bbox.width == 0){
            cout << "Select bounding box" << endl;
            bbox = selectROI("Tracking", frame, true, false); 
            tracker.init(bbox, frame);
        }

        double timer = (double)getTickCount();
        // Update the tracking result
        bbox = tracker.update(frame);
         
        // Calculate Frames per second (FPS)
        float fps = getTickFrequency() / ((double)getTickCount() - timer);
         
        if (1)
        {
            // Tracking success : Draw the tracked object
            rectangle(frame, bbox, Scalar( 255, 0, 0 ), 2, 1 );
        }
        else
        {
            // Tracking failure detected.
            putText(frame, "Tracking failure detected", Point(10,80), FONT_HERSHEY_SIMPLEX, 0.75, Scalar(0,0,255),2);
        }
         
        // Display tracker type on frame
        putText(frame, " Tracker", Point(10,20), FONT_HERSHEY_SIMPLEX, 0.75, Scalar(50,170,50),2);
         
        // Display FPS on frame
        putText(frame, "FPS : " + to_string(int(fps)), Point(10,50), FONT_HERSHEY_SIMPLEX, 0.75, Scalar(50,170,50), 2);
 
        // Display frame.

        imshow("Tracking", frame);
         
        // Exit if ESC pressed.
        int k = waitKey(1);
        if(k == 27)
        {
            break;
        }
 
    }
}